package com.recommender.movierecommender;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovierecommenderApplicationTests {

	@Test
	void contextLoads() {
	}

}
