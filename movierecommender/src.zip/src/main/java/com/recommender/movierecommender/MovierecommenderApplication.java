package com.recommender.movierecommender;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovierecommenderApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovierecommenderApplication.class, args);
	}

}
